# ABU ShopPro RouteMate bridge for Vercel

This project contains Vercel Node.js serverless functions. RouteMate API keys are read only from server-side environment variables.

## Deploy
1. Upload this folder's contents to a GitHub repository (files must be at repository root; `api/` must be top-level).
2. In Vercel choose Add New → Project and import that repository.
3. Before or after the first deploy, open Project → Settings → Environment Variables and add:
   - `ROUTEMATE_API_KEY` = your RouteMate read-only API key (paste only into Vercel)
   - `ROUTEMATE_BASE_URL` = `https://cloud.routemate.ai`
   - `ALLOWED_ORIGIN` = `*` for initial testing. Later restrict to the exact ShopPro website origin.
   Select Production (and Preview if needed).
4. Save and redeploy so the variables are included.
5. Test `https://YOUR-PROJECT.vercel.app/api/health`. Expect `status: ok` and `apiKeyConfigured: true`.
6. Test `https://YOUR-PROJECT.vercel.app/api/routemate/vehicles/locations`. Expect RouteMate JSON or a clear upstream error.
7. In ABU ShopPro, use the base URL `https://YOUR-PROJECT.vercel.app` (do not append an API path) and click Test connection.

## Safety
Never put your RouteMate key in browser HTML, GitHub, or ChatGPT. Do not use a `NEXT_PUBLIC_` prefix. Only GET endpoints are exposed.
