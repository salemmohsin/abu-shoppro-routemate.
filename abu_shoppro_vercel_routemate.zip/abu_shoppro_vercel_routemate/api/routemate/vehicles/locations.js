module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", process.env.ALLOWED_ORIGIN || "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Accept");
  res.setHeader("Cache-Control", "no-store");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });

  const apiKey = process.env.ROUTEMATE_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: "ROUTEMATE_API_KEY is not configured in Vercel Environment Variables.",
      code: "MISSING_API_KEY"
    });
  }

  const baseUrl = (process.env.ROUTEMATE_BASE_URL || "https://cloud.routemate.ai").replace(/\/+$/, "");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  try {
    const upstream = await fetch(baseUrl + "/api/v0/vehicles/locations", {
      method: "GET",
      headers: { "Accept": "application/json", "X-Api-Key": apiKey },
      signal: controller.signal
    });

    const raw = await upstream.text();
    let data;
    try { data = raw ? JSON.parse(raw) : {}; }
    catch { data = { message: raw.slice(0, 1000) }; }

    if (!upstream.ok) {
      return res.status(502).json({
        error: "RouteMate rejected the request.",
        upstreamStatus: upstream.status,
        details: data
      });
    }
    return res.status(200).json(data);
  } catch (err) {
    return res.status(502).json({
      error: err && err.name === "AbortError" ? "RouteMate request timed out." : "Could not reach RouteMate API.",
      code: err && err.name === "AbortError" ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR"
    });
  } finally {
    clearTimeout(timeout);
  }
};
